#!/bin/bash
mkdir /root/project
mkdir /root/project/java
git clone $1 /root/project/java/
mvn package -f /root/project/java/
jar=$(find /root/project/java/target -name "*.jar")
xfce4-terminal -e 'bash -c "java -jar '"$jar"';bash"'
 