#!/bin/bash
xfce4-terminal -e 'bash -c "'"$1"';bash"'